from django.contrib import admin

# from answer.models import Answer,Comment,like
# # Register your models here.
# admin.ste.register(Answer)
# admin.site.register(Comment)
# admin.site.register(likei)