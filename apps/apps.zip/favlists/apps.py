from django.apps import AppConfig


class FavlistsConfig(AppConfig):
    name = 'favlists'
