from django.apps import AppConfig


class ColumnConfig(AppConfig):
    name = 'column'
