from django.apps import AppConfig


class VerifiacationsConfig(AppConfig):
    name = 'verifiacations'
