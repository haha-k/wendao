from django.apps import AppConfig


class ImgsConfig(AppConfig):
    name = 'imgs'
